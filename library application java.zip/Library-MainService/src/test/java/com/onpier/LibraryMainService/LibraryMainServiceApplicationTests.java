package com.onpier.LibraryMainService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryMainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
